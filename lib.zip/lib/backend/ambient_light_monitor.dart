import 'dart:async';

import 'package:ambient_light/ambient_light.dart';
import 'package:flutter/foundation.dart';

/// Monitors ambient light using the `ambient_light` plugin.
/// Designed to be used from a background service isolate.
class AmbientLightMonitor {
  AmbientLightMonitor({this.onLightLevelChanged})
      : _ambientLight = AmbientLight();

  /// Callback invoked whenever a new lux value is available.
  /// Will also be called with the initial reading (if any).
  final void Function(double lux)? onLightLevelChanged;

  final AmbientLight _ambientLight;

  StreamSubscription<double>? _subscription;
  double? _lastLux;
  bool _initialized = false;

  /// Last known lux value (may be `null` if sensor is unavailable).
  double? get lastLux => _lastLux;

  /// Whether the stream listener is currently attached.
  bool get isInitialized => _initialized;

  /// Initializes the ambient light monitor by:
  /// 1. Fetching an initial lux reading.
  /// 2. Subscribing to the ambient light stream.
  ///
  /// Returns `true` if the stream is successfully attached and at
  /// least one reading (initial or stream) is obtained; otherwise `false`.
  ///
  /// Throws only in truly unexpected situations (e.g. plugin misconfiguration).
  Future<bool> initialize() async {
    if (_initialized) {
      debugPrint(
        '[AmbientLightMonitor] initialize() skipped: already initialized',
      );
      return true;
    }

    debugPrint('[AmbientLightMonitor] initialize() entered');

    bool hadAnyReading = false;

    // 1. Read initial value
    try {
      final initialLux = await _ambientLight.currentAmbientLight();

      if (initialLux != null) {
        _lastLux = initialLux;
        hadAnyReading = true;
        debugPrint(
          '[AmbientLightMonitor] Ambient light initial: $initialLux lux',
        );
        onLightLevelChanged?.call(initialLux);
      } else {
        debugPrint(
          '[AmbientLightMonitor] Ambient light initial: sensor unavailable '
              '(plugin returned null)',
        );
      }
    } catch (error, stackTrace) {
      debugPrint(
        '[AmbientLightMonitor] Ambient light initial read failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);
    }

    // 2. Attach stream listener
    try {
      _subscription = _ambientLight.ambientLightStream.listen(
            (double lux) {
          _lastLux = lux;
          hadAnyReading = true;

          debugPrint('[AmbientLightMonitor] Ambient light update: $lux lux');
          onLightLevelChanged?.call(lux);
        },
        onError: (Object error, StackTrace stackTrace) {
          debugPrint(
            '[AmbientLightMonitor] Ambient light stream error: $error',
          );
          debugPrintStack(stackTrace: stackTrace);
        },
      );

      _initialized = true;
      debugPrint(
        '[AmbientLightMonitor] Stream listener attached '
            '(initialized=$hadAnyReading, lastLux=$_lastLux)',
      );
    } catch (error, stackTrace) {
      debugPrint(
        '[AmbientLightMonitor] Ambient light stream attach failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);

      _subscription = null;
      _initialized = false;
      return false;
    }

    return hadAnyReading;
  }

  /// Cancels the stream subscription and resets initialization flag.
  Future<void> dispose() async {
    debugPrint('[AmbientLightMonitor] dispose() called');
    try {
      await _subscription?.cancel();
    } catch (error, stackTrace) {
      debugPrint(
        '[AmbientLightMonitor] dispose() error while cancelling: $error',
      );
      debugPrintStack(stackTrace: stackTrace);
    }
    _subscription = null;
    _initialized = false;
  }
}
