// lib/backend/nsfw_detection.dart

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:image/image.dart' as img;
import 'package:nsfw_detector_flutter/nsfw_detector_flutter.dart';

class NSFWDetectionController {
  static final NSFWDetectionController _instance =
  NSFWDetectionController._internal();

  factory NSFWDetectionController() => _instance;

  NSFWDetectionController._internal();

  static const _screenshotChannel =
  MethodChannel('monitor/screenshot/capture');

  static const _controlChannel =
  MethodChannel('com.example.overlay/control');

  NsfwDetector? _detector;

  Timer? _detectionTimer;

  bool _isActive = false;
  bool _isProcessing = false;
  bool _isOverlayActive = false;

  // True when NSFW itself created the overlay.
  // False when the posture monitor already had one running.
  bool _ownsOverlay = false;

  bool _hasOverlayPermission = false;

  DateTime _lastShown =
  DateTime.now().subtract(
    const Duration(seconds: 10),
  );

  // ---------------------------------------------------------------------------
  // Initialization
  // ---------------------------------------------------------------------------

  Future<void> init() async {
    _detector ??= await NsfwDetector.load();

    _hasOverlayPermission =
    await FlutterOverlayWindow.isPermissionGranted();

    _controlChannel.setMethodCallHandler(
          (call) async {
        if (call.method == 'resumeDetection') {
          debugPrint(
            '[NSFW] Resuming detection via control channel',
          );

          _isOverlayActive = false;
          _ownsOverlay = false;

          if (!_isActive) {
            start();
          }
        }
      },
    );
  }

  // ---------------------------------------------------------------------------
  // Enable / disable
  // ---------------------------------------------------------------------------

  Future<bool> enable() async {
    await init();

    // Overlay permission is an Android app permission and should only
    // be requested if it is genuinely missing.
    if (!_hasOverlayPermission) {
      final granted =
      await FlutterOverlayWindow.requestPermission();

      _hasOverlayPermission = granted == true;
    }

    if (!_hasOverlayPermission) {
      debugPrint(
        '[NSFW] Overlay permission was not granted.',
      );

      return false;
    }

    start();

    return true;
  }

  Future<void> disable() async {
    stop();

    await _closeOverlay(
      forceClose: true,
    );
  }

  // ---------------------------------------------------------------------------
  // Start / stop
  // ---------------------------------------------------------------------------

  void start() {
    if (_isActive) return;

    if (!_hasOverlayPermission) {
      debugPrint(
        '[NSFW] Cannot start: overlay permission missing.',
      );
      return;
    }

    _isActive = true;

    _detectionTimer?.cancel();

    _detectionTimer = Timer.periodic(
      const Duration(seconds: 5),
          (_) => _captureAndDetect(),
    );

    debugPrint('[NSFW] Detection started');
  }

  void stop() {
    _isActive = false;

    _detectionTimer?.cancel();
    _detectionTimer = null;

    debugPrint('[NSFW] Detection stopped');
  }

  // ---------------------------------------------------------------------------
  // Screenshot + detection
  // ---------------------------------------------------------------------------

  Future<void> _captureAndDetect() async {
    if (!_isActive ||
        _isProcessing ||
        _detector == null ||
        !_hasOverlayPermission) {
      return;
    }

    _isProcessing = true;

    try {
      final b64 =
      await _screenshotChannel.invokeMethod<String>(
        'captureScreen',
      );

      if (b64 == null || !_isActive) {
        return;
      }

      final image =
      img.decodeImage(base64Decode(b64));

      if (image == null || !_isActive) {
        return;
      }

      final result =
      await _detector!.detectNSFWFromImage(image);

      debugPrint(
        '[NSFW] Detected: ${result?.isNsfw}',
      );

      final now = DateTime.now();

      if (result?.isNsfw == true &&
          !_isOverlayActive &&
          now.difference(_lastShown).inSeconds > 10) {
        _lastShown = now;

        await _showOverlay();
      }
    } on PlatformException catch (e) {
      debugPrint(
        '[NSFW] Platform detection error: '
            '${e.code}: ${e.message}',
      );
    } catch (e, stackTrace) {
      debugPrint(
        '[NSFW] Detection error: $e',
      );

      debugPrint(
        '$stackTrace',
      );
    } finally {
      _isProcessing = false;
    }
  }

  // ---------------------------------------------------------------------------
  // Overlay HUD
  // ---------------------------------------------------------------------------

  Future<void> _showOverlay() async {
    if (!_isActive ||
        !_hasOverlayPermission ||
        _isOverlayActive) {
      return;
    }

    try {
      final alreadyActive =
      await FlutterOverlayWindow.isActive();

      // The posture monitor may already have the HUD open.
      // In that case we reuse it rather than creating a second overlay.
      if (!alreadyActive) {
        await FlutterOverlayWindow.showOverlay(
          height: 800,
          alignment: OverlayAlignment.center,
          flag: OverlayFlag.defaultFlag,
          visibility:
          NotificationVisibility.visibilityPublic,
          positionGravity: PositionGravity.auto,
        );

        _ownsOverlay = true;

        // Give the overlay isolate a moment to initialize.
        await Future<void>.delayed(
          const Duration(milliseconds: 150),
        );
      } else {
        _ownsOverlay = false;
      }

      _isOverlayActive = true;

      // Tell the existing OverlayHud to switch to NSFW mode.
      await FlutterOverlayWindow.shareData({
        'type': 'nsfw',
      });

      debugPrint(
        '[NSFW] NSFW HUD displayed',
      );

    } catch (e, stackTrace) {
      debugPrint(
        '[NSFW] Failed to show HUD: $e',
      );

      debugPrint(
        '$stackTrace',
      );

      _isOverlayActive = false;
      _ownsOverlay = false;
    }
  }

  Future<void> _closeOverlay({
    bool forceClose = false,
  }) async {
    if (!_isOverlayActive && !forceClose) {
      return;
    }

    try {
      // First tell the HUD that NSFW mode is over.
      if (await FlutterOverlayWindow.isActive()) {
        await FlutterOverlayWindow.shareData({
          'type': 'none',
        });
      }

      // If the posture monitor owned the HUD, don't close it.
      //
      // NSFW only temporarily changes its content.
      if (_ownsOverlay &&
          await FlutterOverlayWindow.isActive()) {
        await FlutterOverlayWindow.closeOverlay();
      } else if (forceClose &&
          await FlutterOverlayWindow.isActive()) {
        // Explicitly disabling NSFW should also clear an
        // NSFW-created overlay.
        await FlutterOverlayWindow.closeOverlay();
      }
    } catch (e) {
      debugPrint(
        '[NSFW] Error closing HUD: $e',
      );
    } finally {
      _isOverlayActive = false;
      _ownsOverlay = false;

      debugPrint(
        '[NSFW] NSFW HUD cleared',
      );
    }
  }
}