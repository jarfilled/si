import 'dart:async';
import 'package:flutter/foundation.dart';

class MetricsManager extends ChangeNotifier {
  static final MetricsManager _instance = MetricsManager._internal();
  factory MetricsManager() => _instance;
  MetricsManager._internal();

  final Map<String, Stopwatch> _timers = {
    'tooClose': Stopwatch(),
    'hunch': Stopwatch(),
    'neck': Stopwatch(),
    'wrist': Stopwatch(),
    'lowLight': Stopwatch(),
  };

  final Map<String, Duration> _accumulated = {
    'tooClose': Duration.zero,
    'hunch': Duration.zero,
    'neck': Duration.zero,
    'wrist': Duration.zero,
    'lowLight': Duration.zero,
  };

  void start(String type) {
    final timer = _timers[type];
    if (timer != null && !timer.isRunning) {
      timer.start();
      notifyListeners();
    }
  }

  void stop(String type) {
    final timer = _timers[type];
    if (timer != null && timer.isRunning) {
      timer.stop();
      _accumulated[type] = _accumulated[type]! + timer.elapsed;
      timer.reset();
      notifyListeners();
    }
  }

  /// Returns accumulated durations PLUS any time currently on a running
  /// stopwatch, so a live-running metric is reflected without waiting for stop().
  Map<String, Duration> getDailyReport() {
    final report = <String, Duration>{};
    for (final key in _accumulated.keys) {
      final running = _timers[key]?.isRunning == true
          ? _timers[key]!.elapsed
          : Duration.zero;
      report[key] = _accumulated[key]! + running;
    }
    return report;
  }

  /// Serialized snapshot (seconds) for cross-isolate transfer.
  Map<String, int> toSeconds() =>
      getDailyReport().map((k, v) => MapEntry(k, v.inSeconds));

  void reset() {
    for (final key in _accumulated.keys) {
      _accumulated[key] = Duration.zero;
      _timers[key]?.reset();
    }
    notifyListeners();
  }
}
