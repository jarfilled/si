import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/background_service.dart';
import 'exercise_center_page.dart';
import 'health_summary_page.dart';
import 'posture_analysis_page.dart';
import 'profile_page.dart';
import 'womens_health_page.dart';

class MainNavigationScreen extends StatefulWidget {
  final String userGender;

  const MainNavigationScreen({
    Key? key,
    required this.userGender,
  }) : super(key: key);

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  static const Color primaryGreen = Color(0xFF42D2A7);
  static const Color bgColor = Color(0xFFF4F9F7);
  static const Color textDark = Color(0xFF2C3E50);

  late List<Widget> _pages;
  late List<BottomNavigationBarItem> _navItems;

  StreamSubscription<Map<String, dynamic>?>? _statusSubscription;

  bool _isServiceAlive = false;
  DateTime? _lastHeartbeat;
  bool _isStartingMonitoring = false;

  @override
  void initState() {
    super.initState();
    _setupPagesAndNav();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkPrivacyAgreement();
    });
  }

  @override
  void dispose() {
    _statusSubscription?.cancel();
    super.dispose();
  }

  void _setupPagesAndNav() {
    _pages = [
      const HealthSummaryPage(),
      const PostureAnalysisPage(),
      const ExerciseCenterPage(),
    ];

    _navItems = [
      const BottomNavigationBarItem(
        icon: Icon(Icons.home_filled),
        label: 'سلامت',
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.accessibility_new),
        label: 'وضعیت بدن',
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.fitness_center),
        label: 'ورزش',
      ),
    ];

    if (widget.userGender == 'female') {
      _pages.add(const WomensHealthPage());
      _navItems.add(
        const BottomNavigationBarItem(
          icon: Icon(Icons.favorite),
          label: 'بانوان',
        ),
      );
    }

    _pages.add(const ProfilePage());
    _navItems.add(
      const BottomNavigationBarItem(
        icon: Icon(Icons.person),
        label: 'پروفایل',
      ),
    );
  }

  Future<void> _checkPrivacyAgreement() async {
    final prefs = await SharedPreferences.getInstance();
    final hasAgreed = prefs.getBool('has_agreed_privacy') ?? false;

    if (!mounted) return;

    if (!hasAgreed) {
      _showPrivacyDialog(prefs);
    } else {
      await _startMonitoring();
    }
  }

  Future<void> _startMonitoring() async {
    if (_isStartingMonitoring) return;
    _isStartingMonitoring = true;

    try {
      final permissions = await [
        Permission.camera,
        Permission.notification,
      ].request();

      if (!permissions[Permission.camera]!.isGranted) {
        _showMessage(
          'برای فعال‌سازی مانیتورینگ، اجازه دسترسی به دوربین لازم است.',
          isError: true,
        );
        return;
      }

      final isOverlayGranted =
      await FlutterOverlayWindow.isPermissionGranted();

      if (!isOverlayGranted) {
        await FlutterOverlayWindow.requestPermission();
      }

      final user = Supabase.instance.client.auth.currentUser;

      if (user == null) {
        debugPrint('Monitoring not started: no authenticated user.');

        _showMessage(
          'جلسه ورود شما پیدا نشد. لطفاً دوباره وارد شوید.',
          isError: true,
        );
        return;
      }

      final calibrationData = await Supabase.instance.client
          .from('users')
          .select('hunch_divisor')
          .eq('id', user.id)
          .maybeSingle();

      final divisor =
      (calibrationData?['hunch_divisor'] as num?)?.toDouble();

      if (divisor == null || !divisor.isFinite || divisor <= 0) {
        debugPrint(
          'Monitoring not started: hunch_divisor is missing or invalid.',
        );

        _showMessage(
          'کالیبراسیون وضعیت بدن پیدا نشد. لطفاً ابتدا کالیبراسیون را انجام دهید.',
          isError: true,
        );
        return;
      }

      // Bridge from the UI isolate to the background-service isolate.
      // onStart() will read this saved value and pass it to Kotlin.
      await BackgroundMonitorService.saveHunchDivisor(divisor);

      debugPrint('Saved hunch_divisor for monitoring: $divisor');

      final alreadyRunning = await BackgroundMonitorService.isRunning;

      await BackgroundMonitorService.initialize();

      if (!alreadyRunning) {
        await Future.delayed(const Duration(milliseconds: 500));
        BackgroundMonitorService.start();
      }

      _listenToServiceStatus();

      _showMessage('سرویس‌های نظارتی با موفقیت فعال شدند.');
    } catch (e, stackTrace) {
      debugPrint('Error starting monitoring: $e');
      debugPrintStack(stackTrace: stackTrace);

      _showMessage(
        'خطا در فعال‌سازی سرویس‌های نظارتی.',
        isError: true,
      );
    } finally {
      _isStartingMonitoring = false;
    }
  }

  void _listenToServiceStatus() {
    _statusSubscription?.cancel();

    _statusSubscription =
        BackgroundMonitorService.statusStream.listen((event) {
          if (event == null || !mounted) return;

          setState(() {
            _isServiceAlive = event['running'] == true;
            _lastHeartbeat = DateTime.now();
          });
        });
  }

  void _showMessage(
      String message, {
        bool isError = false,
      }) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(fontFamily: 'Vazirmatn'),
        ),
        backgroundColor: isError ? Colors.red.shade600 : primaryGreen,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showPrivacyDialog(SharedPreferences prefs) {
    bool isChecked = false;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: StatefulBuilder(
            builder: (context, setDialogState) {
              return AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                backgroundColor: Colors.white,
                title: const Text(
                  'حریم خصوصی و دسترسی‌ها',
                  style: TextStyle(
                    color: textDark,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Vazirmatn',
                  ),
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'برای عملکرد صحیح این برنامه (نظارت بر وضعیت گردن و استراحت چشم‌ها)، نیاز به پردازش تصویر دوربین شما در پس‌زمینه است.\n\nتمامی پردازش‌ها کاملاً روی دستگاه شما انجام شده و هیچ تصویری ذخیره یا به سروری ارسال نمی‌شود.',
                      style: TextStyle(
                        fontSize: 14,
                        color: textDark,
                        height: 1.6,
                        fontFamily: 'Vazirmatn',
                      ),
                      textAlign: TextAlign.justify,
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Checkbox(
                          value: isChecked,
                          activeColor: primaryGreen,
                          onChanged: (value) {
                            setDialogState(() {
                              isChecked = value ?? false;
                            });
                          },
                        ),
                        const Expanded(
                          child: Text(
                            'شرایط را خوانده و با دسترسی‌ها موافقم.',
                            style: TextStyle(
                              fontSize: 13,
                              color: textDark,
                              fontFamily: 'Vazirmatn',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: isChecked
                        ? () async {
                      await prefs.setBool(
                        'has_agreed_privacy',
                        true,
                      );

                      if (!mounted) return;

                      Navigator.of(ctx).pop();
                      await _startMonitoring();
                    }
                        : null,
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: isChecked
                          ? primaryGreen
                          : Colors.grey.shade400,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                    ),
                    child: const Text(
                      'تأیید و ادامه',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Vazirmatn',
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildServiceStatusIndicator() {
    final stale = _lastHeartbeat == null ||
        DateTime.now().difference(_lastHeartbeat!) >
            const Duration(seconds: 12);

    final active = _isServiceAlive && !stale;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: active
            ? primaryGreen.withOpacity(0.1)
            : Colors.grey.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.circle,
            size: 10,
            color: active ? primaryGreen : Colors.grey,
          ),
          const SizedBox(width: 8),
          Text(
            active ? 'مانیتورینگ فعال' : 'در انتظار سرویس...',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              fontFamily: 'Vazirmatn',
              color: active ? primaryGreen : Colors.grey.shade700,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: bgColor,
          elevation: 0,
          automaticallyImplyLeading: false,
          title: _buildServiceStatusIndicator(),
        ),
        body: IndexedStack(
          index: _currentIndex,
          children: _pages,
        ),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, -5),
              ),
            ],
          ),
          child: BottomNavigationBar(
            currentIndex: _currentIndex,
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            backgroundColor: Colors.white,
            selectedItemColor: primaryGreen,
            unselectedItemColor: Colors.grey.shade400,
            selectedLabelStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'Vazirmatn',
              fontSize: 12,
            ),
            unselectedLabelStyle: const TextStyle(
              fontWeight: FontWeight.normal,
              fontFamily: 'Vazirmatn',
              fontSize: 11,
            ),
            type: BottomNavigationBarType.fixed,
            elevation: 0,
            items: _navItems,
          ),
        ),
      ),
    );
  }
}
