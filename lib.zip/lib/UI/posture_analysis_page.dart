import 'dart:async';
import 'package:flutter/material.dart';
import '../services/background_service.dart';

class PostureAnalysisPage extends StatefulWidget {
  const PostureAnalysisPage({Key? key}) : super(key: key);

  @override
  _PostureAnalysisPageState createState() => _PostureAnalysisPageState();
}

class _PostureAnalysisPageState extends State<PostureAnalysisPage> {
  StreamSubscription? _statusSubscription;

  final Map<String, int> _metricsData = {
    'hunch': 0,
    'neck': 0,
    'wrist': 0,
    'tooClose': 0,
    'lowLight': 0,
  };

  @override
  void initState() {
    super.initState();
    _listenToBackgroundService();
  }

  void _listenToBackgroundService() {
    _statusSubscription = BackgroundMonitorService.statusStream.listen((data) {
      if (!mounted) return;
      setState(() {
        // Handle snapshot data (root level keys)
        if (data!.containsKey('hunch')) {
          _metricsData['hunch'] = data['hunch'] as int? ?? 0;
          _metricsData['neck'] = data['neck'] as int? ?? 0;
          _metricsData['wrist'] = data['wrist'] as int? ?? 0;
          _metricsData['tooClose'] = data['tooClose'] as int? ?? 0;
          _metricsData['lowLight'] = data['lowLight'] as int? ?? 0;
        }

        // Handle event-based data payload
        if (data.containsKey('metrics')) {
          final metricsPayload = data['metrics'] as Map<dynamic, dynamic>;
          _metricsData['hunch'] = (metricsPayload['hunch'] as num?)?.toInt() ?? _metricsData['hunch']!;
          _metricsData['neck'] = (metricsPayload['neck'] as num?)?.toInt() ?? _metricsData['neck']!;
          _metricsData['wrist'] = (metricsPayload['wrist'] as num?)?.toInt() ?? _metricsData['wrist']!;
          _metricsData['tooClose'] = (metricsPayload['tooClose'] as num?)?.toInt() ?? _metricsData['tooClose']!;
          _metricsData['lowLight'] = (metricsPayload['lowLight'] as num?)?.toInt() ?? _metricsData['lowLight']!;
        }
      });
    });
  }

  @override
  void dispose() {
    _statusSubscription?.cancel();
    super.dispose();
  }

  String _formatDuration(int seconds) {
    final duration = Duration(seconds: seconds);
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Posture Analysis'),
        backgroundColor: const Color(0xFF98FF98),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildMetricCard('Hunch Duration', _metricsData['hunch']!),
          _buildMetricCard('Neck Strain Duration', _metricsData['neck']!),
          _buildMetricCard('Wrist Strain Duration', _metricsData['wrist']!),
          _buildMetricCard('Screen Too Close', _metricsData['tooClose']!),
          _buildMetricCard('Low Light Exposure', _metricsData['lowLight']!),
        ],
      ),
    );
  }

  Widget _buildMetricCard(String title, int seconds) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: Text(
          _formatDuration(seconds),
          style: const TextStyle(fontSize: 16, color: Colors.teal),
        ),
      ),
    );
  }
}
