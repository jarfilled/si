import 'package:flutter/material.dart';

class ExerciseCenterPage extends StatelessWidget {
  const ExerciseCenterPage({Key? key}) : super(key: key);

  final Color primaryGreen = const Color(0xFF42D2A7);
  final Color darkTeal = const Color(0xFF145954);
  final Color bgColor = const Color(0xFFF7F9F9);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: Text('مرکز تمرین', style: TextStyle(color: darkTeal, fontWeight: FontWeight.bold)),
          centerTitle: true,
        ),
        body: ListView(
          padding: const EdgeInsets.all(20.0),
          children: [
            _buildMotivationalBanner(),
            const SizedBox(height: 25),
            Text('تمرینات پیشنهادی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: darkTeal)),
            const SizedBox(height: 15),
            _buildExerciseCard('رفع خستگی چشم', 'قانون ۲۰-۲۰-۲۰', '۳ دقیقه', Icons.remove_red_eye, 'آسان'),
            _buildExerciseCard('کشش گردن و شانه', 'کاهش درد و گرفتگی', '۵ دقیقه', Icons.self_improvement, 'متوسط'),
            _buildExerciseCard('اصلاح قوز کمر', 'تقویت عضلات پشت', '۱۰ دقیقه', Icons.accessibility_new, 'متوسط'),
            _buildExerciseCard('نرمش مچ دست', 'پیشگیری از تونل کارپال', '۴ دقیقه', Icons.back_hand, 'آسان'),
          ],
        ),
      ),
    );
  }

  Widget _buildMotivationalBanner() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: primaryGreen.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: primaryGreen.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('زمان یک استراحت کوتاه است!', style: TextStyle(color: darkTeal, fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('تنها چند دقیقه تمرین در روز می‌تواند تاثیر چشمگیری روی سلامت شما بگذارد.', style: TextStyle(color: darkTeal.withOpacity(0.8), fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(width: 15),
          Icon(Icons.directions_run, size: 50, color: primaryGreen),
        ],
      ),
    );
  }

  Widget _buildExerciseCard(String title, String desc, String time, IconData icon, String level) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: darkTeal, size: 30),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: darkTeal)),
                const SizedBox(height: 4),
                Text(desc, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.timer, size: 14, color: primaryGreen),
                    const SizedBox(width: 4),
                    Text(time, style: TextStyle(fontSize: 12, color: primaryGreen, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 15),
                    Icon(Icons.bar_chart, size: 14, color: Colors.grey[500]),
                    const SizedBox(width: 4),
                    Text(level, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                  ],
                )
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: Colors.grey[400]),
        ],
      ),
    );
  }
}
