import 'package:flutter/material.dart';

class WomensHealthPage extends StatelessWidget {
  const WomensHealthPage({Key? key}) : super(key: key);

  final Color primaryGreen = const Color(0xFF42D2A7);
  final Color darkTeal = const Color(0xFF145954);
  final Color bgColor = const Color(0xFFF7F9F9);
  final Color softPink = const Color(0xFFFFA5B7); // رنگ ویژه سلامت زنان

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: Text('سلامت و قاعدگی', style: TextStyle(color: darkTeal, fontWeight: FontWeight.bold)),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildCycleTracker(),
              const SizedBox(height: 30),
              Align(
                alignment: Alignment.centerRight,
                child: Text('ثبت روزانه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: darkTeal)),
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildQuickLogButton('علائم فیزیکی', Icons.water_drop, softPink),
                  _buildQuickLogButton('وضعیت خلق‌وخو', Icons.mood, Colors.orangeAccent),
                  _buildQuickLogButton('یادداشت', Icons.edit_note, primaryGreen),
                ],
              ),
              const SizedBox(height: 30),
              _buildHealthTipCard(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCycleTracker() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 30),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        boxShadow: [BoxShadow(color: softPink.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 10))],
      ),
      child: Column(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 180,
                height: 180,
                child: CircularProgressIndicator(
                  value: 0.5, // روز ۱۴ از ۲۸
                  strokeWidth: 15,
                  backgroundColor: bgColor,
                  color: softPink,
                  strokeCap: StrokeCap.round,
                ),
              ),
              Column(
                children: [
                  Text('روز ۱۴', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: darkTeal)),
                  const SizedBox(height: 5),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: softPink.withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                    child: Text('فاز تخمک‌گذاری', style: TextStyle(color: softPink, fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text('احتمال باروری در بالاترین سطح قرار دارد', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildQuickLogButton(String title, IconData icon, Color color) {
    return Column(
      children: [
        Container(
          width: 70,
          height: 70,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 5))],
          ),
          child: IconButton(
            icon: Icon(icon, color: color, size: 30),
            onPressed: () {},
          ),
        ),
        const SizedBox(height: 10),
        Text(title, style: TextStyle(color: darkTeal, fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _buildHealthTipCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: softPink.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: softPink.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.self_improvement, color: softPink, size: 40),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('نکته سلامتی امروز', style: TextStyle(color: darkTeal, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                Text('در این فاز از چرخه، سطح انرژی شما بالاست. انجام تمرینات هوازی و کششی سبک بسیار پیشنهاد می‌شود.', style: TextStyle(color: Colors.grey[700], fontSize: 12, height: 1.5)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
