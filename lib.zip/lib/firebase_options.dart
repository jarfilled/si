
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDpfcEhkHn1KMJgVhp9y1BV7YriPfkiyr4',
    appId: '1:221953884928:web:754b0e3c2b23b4891f29e5',
    messagingSenderId: '221953884928',
    projectId: 'posture-dcd77',
    authDomain: 'posture-dcd77.firebaseapp.com',
    storageBucket: 'posture-dcd77.firebasestorage.app',
    measurementId: 'G-4FGKGBCK4R',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDyE8UOUEdmCjEDVjOh94W-8yv65uEIwEU',
    appId: '1:221953884928:android:b29082816ea8285d1f29e5',
    messagingSenderId: '221953884928',
    projectId: 'posture-dcd77',
    storageBucket: 'posture-dcd77.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyBBr8KBWrvICShPuQaFH8XDUt1DX_qkwz8',
    appId: '1:221953884928:ios:66fff222fa709b0e1f29e5',
    messagingSenderId: '221953884928',
    projectId: 'posture-dcd77',
    storageBucket: 'posture-dcd77.firebasestorage.app',
    iosBundleId: 'com.example.monitor',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyBBr8KBWrvICShPuQaFH8XDUt1DX_qkwz8',
    appId: '1:221953884928:ios:66fff222fa709b0e1f29e5',
    messagingSenderId: '221953884928',
    projectId: 'posture-dcd77',
    storageBucket: 'posture-dcd77.firebasestorage.app',
    iosBundleId: 'com.example.monitor',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyDpfcEhkHn1KMJgVhp9y1BV7YriPfkiyr4',
    appId: '1:221953884928:web:6540513ffde07a901f29e5',
    messagingSenderId: '221953884928',
    projectId: 'posture-dcd77',
    authDomain: 'posture-dcd77.firebaseapp.com',
    storageBucket: 'posture-dcd77.firebasestorage.app',
    measurementId: 'G-7LG9LLXZRR',
  );
}
